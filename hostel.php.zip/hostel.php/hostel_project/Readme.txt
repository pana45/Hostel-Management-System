Login Details for admin : admin/Test@1234
Login Details for user : test@gmail.com/Test@123